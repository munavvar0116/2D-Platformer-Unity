using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;   // player
    public float smoothSpeed = 5f;

    void LateUpdate()
    {
        Vector3 newPos = new Vector3(target.position.x, target.position.y, -10f);
        transform.position = Vector3.Lerp(transform.position, newPos, smoothSpeed * Time.deltaTime);
    }
}